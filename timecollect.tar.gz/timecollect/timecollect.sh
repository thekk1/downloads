#!/bin/bash

( cd "$(dirname $0)" ; exec java -cp osgi.jar:timecollect.starter.jar de.haumacher.timecollect.starter.Main )
