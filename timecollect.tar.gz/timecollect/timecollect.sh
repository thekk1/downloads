#!/bin/bash

( cd "$(dirname $0)" ; exec /usr/lib/jvm/java-8-openjdk-amd64/jre/bin/java -cp osgi.jar:timecollect.starter.jar de.haumacher.timecollect.starter.Main )
